/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dsagaragemgmt;

/**
 *
 * @author Ganindudesh
 */
public class car {
    char action;
    String numberPlate;

    public car(char action, String numberPlate) {
        this.action = action;
        this.numberPlate = numberPlate;
    }

    public char getAction() {
        return action;
    }

    public String getNumberPlate() {
        return numberPlate;
    }
    
    
    
    
}
